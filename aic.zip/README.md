# AIC21-Client-Python
- Write your code in `AI.py`
- Use PyInstaller to create binary executable file
  - `python -m PyInstaller --onefile Controller.py`
- Pass output file path (path to `dist/Controller`) to server as args ( `--first-team` or `--second-team` )
